Back-Propagation
========================

Backpropagation is a common method of training artificial neural networks. The method calculates the gradient of a loss function with respects to all the weights in the network. The gradient is fed to the optimization method which in turn uses it to update the weights, in an attempt to minimize the loss function. Backpropagation requires a known, desired output for each input value in order to calculate the loss function gradient.  The backpropagation learning algorithm is divided into two phases: propagation and weight update.

Note: Original implementation taken from the [Rodinia Benchmark Suite](https://www.cs.virginia.edu/~skadron/wiki/rodinia)
